// Clay Zimmerman
// James Madison University
// SMAD 308 - Interactive Design II
// Animation

// global variables
var x = 500;		// x coordinate
var y = 200;		// y coordinate
var easing = 0.10;		// easing rate

function setup() {
	createCanvas(1200, 800);
}

function draw() {
	background(154, 127, 199);
	
	// easing animation based on where the mouse is relative to the x axis
	var targetX = mouseX;
	x += (targetX - x) * easing;
	
	// easing animation based on where the mouse is relative to the y axis
	var targetY = mouseY;
	y += (targetY - y) * easing;
	// since each shape was drawn relative to the x and y coordinates established as variables at the top,
	// all of the shapes combined move together at the same time when the mouse moves
	
	// cockpit
	stroke(0);
	strokeWeight(2);
	fill(6, 73, 233);
	quad(x, y, x+100, y, x+130, y+120, x-30, y+120);
	
	fill(0);
	quad(x+20, y+20, x+80, y+20, x+100, y+100, x, y+100);

	stroke(255);
	line(x+25, y+80, x+55, y+40);
	
	stroke(255);
	line(x+40, y+80, x+70, y+40);
	
	
	// ship body
	stroke(0);
	strokeWeight(2);
	fill(6, 73, 233);
	quad(x-50, y+100, x+150, y+100, x+250, y+350, x-150, y+350);
	
	noStroke();
	fill(255, 255, 0);
	quad(x-78, y+170, x+178, y+170, x+190, y+200, x-90, y+200);
	
	// thrusters
	stroke(0);
	strokeWeight(2);
	fill(120);
	rect(x-80, y+350, 100, 20);
	
	fill(120);
	rect(x+80, y+350, 100, 20);
	
	// activates the thrusters when the mouse is pressed
	if (mouseIsPressed) {
		noStroke();
		fill(236, 102, 0);
		arc(x-30, y+371, 80, 80, 0, PI);
		fill(255, 255, 120);
		arc(x-30, y+371, 50, 50, 0, PI);
		
		fill(236, 102, 0);
		arc(x+130, y+371, 80, 80, 0, PI);
		fill(255, 255, 120);
		arc(x+130, y+371, 50, 50, 0, PI);
	}
	
	for (var v = 0; v <= width; v += 100) {
		fill(255, 200, 0);
		stroke(0);
		strokeWeight(2);
		ellipse(100, v, 75, 75);
	}
	
	for (var z = 0; z <= width; z += 100) {
		fill(255, 200, 0);
		ellipse(1100, z, 75, 75);
	}
	
}