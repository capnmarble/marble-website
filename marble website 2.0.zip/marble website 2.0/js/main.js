// Clay Zimmerman
// James Madison University
// SMAD 308 - Interactive Design II
// Portrait
// Samus Aran from "Metroid"

// global variables
var x = 600;
var y = 450;

function setup() {
	createCanvas(1200, 600);
}

function draw() {
	background(100, 0, 255);
	
	// respirator tubes
	noFill();
	stroke(100);
	strokeWeight(25);
	arc(x-60, y-120, 300, 300, PI*0.5, PI*1.08);
	arc(x+60, y-120, 300, 300, PI*1.5, PI*0.5);
	
	// helmet
	fill('#fc8c1c');
	noStroke();
	ellipse(430, 275, 100, 125); // sides
	ellipse(770, 275, 100, 125);
	arc(x, 300, 400, 400, PI, PI*2); // top-half
	quad(400, 300, 800, 300, 700, y, 500, y); // bottom-half
	
	stroke(0);
	strokeWeight(8);
	line(x-75, 116, x-75, 175); // detail lines
	line(x+75, 116, x+75, 175);
	line(x-75, 175, x-55, 195);
	line(x+75, 175, x+55, 195);
	line(x-55, 195, x-55, 235);
	line(x+55, 195, x+55, 235);
	
	// respirator box
	fill(150);
	strokeWeight(5);
	quad(x-85, y-25, x+85, y-25, x+65, y+50, x-65, y+50);
	stroke(0);
	line(x-65, y-10, x+65, y-10); // filter lines
	line(x-60, y+5, x+60, y+5);
	line(x-55, y+20, x+55, y+20);
	line(x-50, y+35, x+50, y+35);
	
	// visor
	fill('#98b418');
	noStroke();
	quad(x-150, y-215, x+150, y-215, x+125, y-140, x-125, y-140); // top
	quad(x-125, y-140, x+125, y-140, x+25, y-65, x-25, y-65); // mid
	rect(x-25, y-75, 50, 48); // bottom
	
	stroke(255);
	strokeWeight(1);
	line(x+10, y-200, x-40, y-125);	// reflection lines
	line(x+30, y-200, x-20, y-125);
	
}